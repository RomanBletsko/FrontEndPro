let a = 10;
let b = 27;
let c = 7;

console.log(a + b * c);
console.log(b - a * c);
console.log(a + c - b);
console.log(b / c + a);
console.log(a * b / c);